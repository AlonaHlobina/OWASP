/*
	Test session management script which does nothing other than expose the right interface
	and define required and optional parameters ;)
*/

function extractWebSession(sessionWrapper) {
}
    	
function clearWebSessionIdentifiers(sessionWrapper) {
}
    	
function processMessageToMatchSession(sessionWrapper) {
}

function getRequiredParamsNames() {
	return ["aaa", "bbb"];
}

function getOptionalParamsNames() {
	return ["ccc", "ddd"];
}
