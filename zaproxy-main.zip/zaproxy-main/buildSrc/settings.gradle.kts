
pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
    }
}
