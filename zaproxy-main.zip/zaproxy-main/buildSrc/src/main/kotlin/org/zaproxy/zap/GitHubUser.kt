package org.zaproxy.zap

data class GitHubUser(val name: String, val email: String, val authToken: String?)
