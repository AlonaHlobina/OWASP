# Security Policy

## Supported Versions

| Version  | Supported          |
| -------- | ------------------ |
| 2.12.0   | :white_check_mark: |
| < 2.12.0 | :x:                |

## Reporting a Vulnerability

Please report any vulnerabilities via our [Bug Bounty Program](https://bugcrowd.com/owaspzap).

Remote Code Execution for this program will be rewarded at __$1000__
